import random
import matplotlib.pyplot as plt


def evolve_system(num_of_particles, particles_in_left, steps):
    n_particles = particles_in_left
    n_history = [n_particles]
    
    for _ in range(steps):
        for _ in range(num_of_particles):

            movement = random.choice([-1, 0, 1])

            n_particles += movement

            if n_particles < 0:
                n_particles = 0

            elif n_particles > num_of_particles:
                n_particles = num_of_particles
        
        n_history.append(n_particles)
    
    return n_history


def plot_evolution(num_of_particles, steps):
    for n in num_of_particles:
        n_history = evolve_system(n, n/2, steps)
        plt.plot(n_history, label=f'N={n}')
    
    plt.xlabel('Steps number')
    plt.ylabel('The number of particles on the left')
    plt.title('evolve system')
    plt.legend()
    plt.show()


if __name__ == "__main__":
    # num_of_particles = [8, 16, 64]
    num_of_particles = [400, 800, 3600]
    # num_of_particles = [8, 16, 64, 400, 800, 3600]
    steps = 100000

    plot_evolution(num_of_particles, steps)