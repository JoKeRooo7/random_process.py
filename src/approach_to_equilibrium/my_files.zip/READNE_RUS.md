## Approach to equilibrium

* [Скрипт `approach_to_equilibrium.py`](#скрипт-approachtoequilibrium2dpy)
    * [Графики](#результаты-эксперимента-графики)
    * [Вывод](#вывод-approachtoequilibriumpy)
* [Скрипт `update_approach_to_equilibrium.py`]
    * [Графики](#графики)
    * [Вывод](#вывод-updateapproachtoequilibriumpy)
 
## Скрипт approach_to_equilibrium.py

В скрипте `approach_to_equilibrium.py` была промоделирована ситуация, для анализа равновесия системы, при котором частицы движутся хаотично, влево и вправо.
Была создана гипотетическиая ситация, в которой задаются количество частиц изначально, и половина из них изначально слева или справа. Возможность движения частицы только по одной кординате абсолютно случайны.


## Результаты эксперимента (графики):

* 100 итераций для системы с 8, 16, 64 частицами.
![first_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_100_8_16_64___1.png)
![second_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_100_8_16_64___2.png)
![third_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_100_8_16_64___2.png)


* 1000 итераций для системы с 8, 16, 64 частицами.
![fourth_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_1000_8_16_64___1.png)
![five_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_1000_8_16_64___2.png)
![six_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_1000_8_16_64___2.png)

* 100 итераций для системы с 400, 800, 3600 частицами.
![seven_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_100__400_800_3600___1.png)
![eight_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_100__400_800_3600___2.png)
![nine_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_100__400_800_3600___3.png)

* 1000 итераций для системы с 400, 800, 3600 частицами.
![ten_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_1000__400_800_3600___1.png)
![eleven_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_1000__400_800_3600___2.png)
![twelve_graphic](../../image/approach_to_equilibrium/approach_to_equilibrium_1000__400_800_3600___3.png)

## Вывод approach_to_equilibrium.py
В результате эксперимента были сделаны следующие выводы:

* Система промежуточно достигает равновесия на короткий промежуток итераций даже если рассматривать два разных критерия:

    * критерий равновесия (изменения количество частиц на одной стороне)

    * критерий равновесия (количество частиц справа и слева одинаковое)

* При большом количестве частиц, система изменяется на незначительное,малозаметное количество частиц, что может быть близко к критерию равновесия. Но все равно достигается на определенный промежуток итераций.


## Скрипт update_approach_to_equilibrium.py
В скрипте смоделирована такая же сиутация как и в [`approach_to_equilibrium.py`](#скрипт-approachtoequilibrium2dpy), только условие такоого, что частица перемещеается вправо, только при условии
$$ r \leq  p = n / N$$
где $r$ - случайное число от 0 до 1, 
$n$ - количество частиц влевой части
$N$ - количество всего частиц


## Графики

* 100 итераций для системы с 8, 16, 64 частицами.
![up_gr_1](../../image/approach_to_equilibrium/up_to_equilibrium_100_8_16_64___1.png)
* 1000 итераций для системы с 8, 16, 64 частицами.
![up_gr_2](../../image/approach_to_equilibrium/up_to_equilibrium_1000_8_16_64___1.png)
* 100 итераций для системы с 400, 800, 3600 частицами.
![up_gr_3](../../image/approach_to_equilibrium/up_to_equilibrium_100__400_800_3600___1.png)
* 1000 итераций для системы с 400, 800, 3600 частицами.
![up_gr_34](../../image/approach_to_equilibrium/up_to_equilibrium_1000__400_800_3600___1.png)

Из за условия, при котором рандом должен быть меньше вероятности частиц на левой сторое, количество частиц слевой стороны при каждой итерации уменьшается. Система стремиться к равновесию.


## Вывод update_approach_to_equilibrium.py

При малом количестве частиц - система находитсья близко к равновесию, но не достигает его. При значительном количестве частиц, система находиться в равновесии.

Время при котором система проходит в состояние равновесия, уже происходит на первых итерациях (< 10).